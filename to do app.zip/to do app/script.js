function addTask() {
    
    const inputBox = document.getElementById('input-box');
    const taskText = inputBox.value.trim();

    if (taskText === '') {
        alert('Please enter a task.');
        return;
    }

    
    const li = document.createElement('li');
    li.textContent = taskText;

    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.onclick = function() {
        li.classList.toggle('checked');
    };

    
    li.prepend(checkbox);

   
    const listContainer = document.getElementById('list-container');
    listContainer.appendChild(li);

   
    inputBox.value = '';
}
